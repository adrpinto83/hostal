# app/schemas/reservation.py
from pydantic import BaseModel, Field
from datetime import date
from typing import Literal

Period = Literal["day", "week", "fortnight", "month"]
Status = Literal["pending", "active", "checked_out", "cancelled"]

class ReservationBase(BaseModel):
    guest_id: int
    room_id: int
    start_date: date
    period: Period
    periods_count: int = Field(ge=1, default=1)
    price_bs: float
    rate_usd: float | None = None
    rate_eur: float | None = None
    notes: str | None = None

class ReservationCreate(ReservationBase):
    pass

class ReservationUpdate(BaseModel):
    start_date: date | None = None
    period: Period | None = None
    periods_count: int | None = Field(default=None, ge=1)
    price_bs: float | None = None
    rate_usd: float | None = None
    rate_eur: float | None = None
    notes: str | None = None
    status: Status | None = None

class ReservationOut(BaseModel):
    id: int
    guest_id: int
    room_id: int
    start_date: date
    end_date: date
    period: Period
    periods_count: int
    price_bs: float
    rate_usd: float | None
    rate_eur: float | None
    status: Status
    notes: str | None

    class Config:
        from_attributes = True

