# app/models/room_rate.py
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import Integer, String, ForeignKey, Enum, Numeric, UniqueConstraint
from ..core.db import Base

class RoomRate(Base):
    __tablename__ = "room_rates"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    room_id: Mapped[int] = mapped_column(ForeignKey("rooms.id", ondelete="CASCADE"), index=True)
    period: Mapped[str] = mapped_column(Enum("day", "week", "fortnight", "month", name="period", create_type=False))
    price_bs: Mapped[float] = mapped_column(Numeric(12,2))
    currency_note: Mapped[str | None] = mapped_column(String(50))  # opcional

    __table_args__ = (UniqueConstraint("room_id", "period", name="uq_room_period"),)
