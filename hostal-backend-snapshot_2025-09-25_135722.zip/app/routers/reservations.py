# app/routers/reservations.py
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from datetime import date
from ..core.db import get_db
from ..core.security import get_current_user, require_roles
from ..schemas.reservation import ReservationCreate, ReservationUpdate, ReservationOut
from ..models.reservation import Reservation, ReservationStatus
from ..services.reservations import has_overlap
from ..core.dates import compute_end_date

router = APIRouter(prefix="/reservations", tags=["reservations"])

@router.post("/", response_model=ReservationOut)
def create_reservation(
    payload: ReservationCreate,
    db: Session = Depends(get_db),
    user=Depends(require_roles("admin", "recepcionista")),
):
    end_date = compute_end_date(payload.start_date, payload.period, payload.periods_count)

    if has_overlap(db, payload.room_id, payload.start_date, end_date):
        raise HTTPException(400, detail="La habitación ya está ocupada en ese rango")

    r = Reservation(
        guest_id=payload.guest_id,
        room_id=payload.room_id,
        start_date=payload.start_date,
        end_date=end_date,
        period=payload.period,
        periods_count=payload.periods_count,
        price_bs=payload.price_bs,
        rate_usd=payload.rate_usd,
        rate_eur=payload.rate_eur,
        status=ReservationStatus.pending,
        notes=payload.notes,
    )
    db.add(r)
    db.commit()
    db.refresh(r)
    return r

@router.get("/", response_model=list[ReservationOut])
def list_reservations(
    db: Session = Depends(get_db),
    user=Depends(require_roles("admin", "recepcionista")),
    guest_id: int | None = None,
    room_id: int | None = None,
    status: str | None = Query(None, pattern="^(pending|active|checked_out|cancelled)$"),
    date_from: date | None = None,
    date_to: date | None = None,
    limit: int = 50,
    offset: int = 0,
):
    q = db.query(Reservation)
    if guest_id:
        q = q.filter(Reservation.guest_id == guest_id)
    if room_id:
        q = q.filter(Reservation.room_id == room_id)
    if status:
        q = q.filter(Reservation.status == status)
    if date_from:
        q = q.filter(Reservation.end_date >= date_from)
    if date_to:
        q = q.filter(Reservation.start_date <= date_to)
    return q.order_by(Reservation.start_date.desc()).offset(offset).limit(limit).all()

@router.get("/{res_id}", response_model=ReservationOut)
def get_reservation(
    res_id: int,
    db: Session = Depends(get_db),
    user=Depends(require_roles("admin", "recepcionista")),
):
    r = db.get(Reservation, res_id)
    if not r:
        raise HTTPException(404, "Reserva no encontrada")
    return r

@router.patch("/{res_id}", response_model=ReservationOut)
def update_reservation(
    res_id: int,
    payload: ReservationUpdate,
    db: Session = Depends(get_db),
    user=Depends(require_roles("admin", "recepcionista")),
):
    r = db.get(Reservation, res_id)
    if not r:
        raise HTTPException(404, "Reserva no encontrada")

    if payload.start_date or payload.period or payload.periods_count:
        start = payload.start_date or r.start_date
        period = payload.period or r.period
        count = payload.periods_count or r.periods_count
        end = compute_end_date(start, period, count)
        if has_overlap(db, r.room_id, start, end, exclude_id=r.id):
            raise HTTPException(400, "Solape con otra reserva")
        r.start_date, r.end_date, r.period, r.periods_count = start, end, period, count

    for field in ("price_bs", "rate_usd", "rate_eur", "notes"):
        val = getattr(payload, field)
        if val is not None:
            setattr(r, field, val)

    if payload.status:
        # validaciones sencillas de flujo
        if r.status == "cancelled" or r.status == "checked_out":
            raise HTTPException(400, "No se puede cambiar una reserva finalizada/cancelada")
        r.status = payload.status

    db.commit()
    db.refresh(r)
    return r

@router.delete("/{res_id}", status_code=204)
def delete_reservation(
    res_id: int,
    db: Session = Depends(get_db),
    user=Depends(require_roles("admin")),  # solo admin
):
    r = db.get(Reservation, res_id)
    if not r:
        raise HTTPException(404, "Reserva no encontrada")
    db.delete(r)
    db.commit()
    return

@router.get("/availability/", summary="Disponibilidad por rango")
def availability(
    room_id: int,
    start_date: date,
    end_date: date,
    db: Session = Depends(get_db),
    user=Depends(require_roles("admin", "recepcionista")),
):
    busy = has_overlap(db, room_id, start_date, end_date)
    return {"room_id": room_id, "available": (not busy)}
