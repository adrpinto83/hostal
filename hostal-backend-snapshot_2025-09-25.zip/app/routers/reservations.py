# app/routers/reservations.py
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date

from ..core.db import get_db
from ..core.deps import require_roles
from ..core.dates import compute_end_date
from ..models.reservation import Reservation, ReservationStatus
from ..models.room import Room
from ..models.guest import Guest
from ..schemas.reservation import ReservationCreate, ReservationUpdate, ReservationOut

router = APIRouter(prefix="/reservations", tags=["reservations"])

@router.get("/", response_model=List[ReservationOut],
            dependencies=[Depends(require_roles("admin","recepcionista"))])
def list_reservations(
    status_filter: Optional[str] = Query(None),
    guest_id: Optional[int] = Query(None),
    room_id: Optional[int] = Query(None),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    db: Session = Depends(get_db),
):
    q = db.query(Reservation)
    if status_filter:
        try:
            q = q.filter(Reservation.status == ReservationStatus(status_filter))
        except Exception:
            raise HTTPException(400, "invalid status")
    if guest_id:
        q = q.filter(Reservation.guest_id == guest_id)
    if room_id:
        q = q.filter(Reservation.room_id == room_id)
    if date_from:
        q = q.filter(Reservation.end_date >= date_from)
    if date_to:
        q = q.filter(Reservation.start_date <= date_to)
    return q.order_by(Reservation.start_date.desc(), Reservation.id.desc()).all()

@router.post("/", response_model=ReservationOut, status_code=status.HTTP_201_CREATED,
             dependencies=[Depends(require_roles("admin","recepcionista"))])
def create_reservation(data: ReservationCreate, db: Session = Depends(get_db)):
    if not db.get(Guest, data.guest_id):
        raise HTTPException(404, "Guest not found")
    room = db.get(Room, data.room_id)
    if not room:
        raise HTTPException(404, "Room not found")

    end_date = compute_end_date(data.start_date, data.period, data.periods_count)

    overlap = db.query(Reservation).filter(
        Reservation.room_id == data.room_id,
        Reservation.status.in_([ReservationStatus.pending, ReservationStatus.active]),
        Reservation.start_date < end_date,
        Reservation.end_date > data.start_date,
    ).first()
    if overlap:
        raise HTTPException(400, "Room already reserved in that period")

    r = Reservation(
        guest_id=data.guest_id,
        room_id=data.room_id,
        start_date=data.start_date,
        end_date=end_date,
        period=data.period, periods_count=data.periods_count,
        price_bs=data.price_bs,
        rate_usd=data.rate_usd, rate_eur=data.rate_eur,
        status=ReservationStatus.pending,
        notes=data.notes,
    )
    db.add(r); db.commit(); db.refresh(r)
    return r

@router.patch("/{reservation_id}", response_model=ReservationOut,
              dependencies=[Depends(require_roles("admin","recepcionista"))])
def update_reservation(reservation_id: int, data: ReservationUpdate, db: Session = Depends(get_db)):
    r = db.get(Reservation, reservation_id)
    if not r:
        raise HTTPException(404, "Reservation not found")

    payload = data.model_dump(exclude_unset=True)
    if any(k in payload for k in ("start_date","period","periods_count")):
        start = payload.get("start_date", r.start_date)
        period = payload.get("period", r.period.value if hasattr(r.period, "value") else r.period)
        count = payload.get("periods_count", r.periods_count)
        r.start_date = start
        r.end_date = compute_end_date(start, period, count)
        r.period = period
        r.periods_count = count

    if "price_bs" in payload: r.price_bs = payload["price_bs"]
    if "rate_usd"  in payload: r.rate_usd  = payload["rate_usd"]
    if "rate_eur"  in payload: r.rate_eur  = payload["rate_eur"]
    if "notes"     in payload: r.notes     = payload["notes"]
    if "status"    in payload:
        try:
            r.status = ReservationStatus(payload["status"])
        except Exception:
            raise HTTPException(400, "invalid status")

    db.commit(); db.refresh(r)
    return r

@router.post("/{reservation_id}/cancel", response_model=ReservationOut,
             dependencies=[Depends(require_roles("admin","recepcionista"))])
def cancel_reservation(reservation_id: int, db: Session = Depends(get_db)):
    r = db.get(Reservation, reservation_id)
    if not r: raise HTTPException(404, "Reservation not found")
    r.status = ReservationStatus.cancelled
    db.commit(); db.refresh(r)
    return r

@router.post("/{reservation_id}/checkin", response_model=ReservationOut,
             dependencies=[Depends(require_roles("admin","recepcionista"))])
def checkin(reservation_id: int, db: Session = Depends(get_db)):
    r = db.get(Reservation, reservation_id)
    if not r: raise HTTPException(404, "Reservation not found")
    r.status = ReservationStatus.active
    db.commit(); db.refresh(r)
    return r

@router.post("/{reservation_id}/checkout", response_model=ReservationOut,
             dependencies=[Depends(require_roles("admin","recepcionista"))])
def checkout(reservation_id: int, db: Session = Depends(get_db)):
    r = db.get(Reservation, reservation_id)
    if not r: raise HTTPException(404, "Reservation not found")
    r.status = ReservationStatus.checked_out
    db.commit(); db.refresh(r)
    return r

@router.delete("/{reservation_id}", status_code=204,
               dependencies=[Depends(require_roles("admin"))])
def delete_reservation(reservation_id: int, db: Session = Depends(get_db)):
    r = db.get(Reservation, reservation_id)
    if not r: raise HTTPException(404, "Reservation not found")
    db.delete(r); db.commit()
    return
