# app/core/dates.py
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta  # instala python-dateutil si no lo tienes

def compute_end_date(start: date, period: str, periods_count: int) -> date:
    """
    Calcula end_date exclusivo (día de salida) según period y periods_count.
    - day: +N días
    - week: +N semanas
    - fortnight: +N quincenas (2 semanas cada una)
    - month: +N meses (respeta calendario real, no 30 días fijos)
    """
    period = period.lower()
    if period == "day":
        return start + timedelta(days=periods_count)
    if period == "week":
        return start + timedelta(weeks=periods_count)
    if period == "fortnight":
        return start + timedelta(days=14 * periods_count)
    if period == "month":
        return start + relativedelta(months=+periods_count)
    raise ValueError("Invalid period")
