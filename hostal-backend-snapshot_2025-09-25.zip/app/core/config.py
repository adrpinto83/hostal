# app/core/config.py
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://hostal:hostal_pass@localhost:5432/hostal_db"

    # aceptar variables extra del .env (POSTGRES_*) sin fallar
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",  # <-- ¡string, no tupla!
    )

settings = Settings()
