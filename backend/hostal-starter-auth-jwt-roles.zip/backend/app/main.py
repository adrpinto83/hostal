from fastapi import FastAPI
from .routers import health, auth, users

app = FastAPI(title="Hostal API (with auth & roles)")

app.include_router(health.router)
app.include_router(auth.router)
app.include_router(users.router)

@app.get("/", tags=["root"])
def root():
    return {"message": "Hostal API up. See /docs"}
