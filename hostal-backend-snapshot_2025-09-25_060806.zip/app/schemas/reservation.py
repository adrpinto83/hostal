# app/schemas/reservation.py
from pydantic import BaseModel, Field, conint, condecimal
from datetime import date
from typing import Optional, Literal

Period = Literal["day", "week", "fortnight", "month"]
Status = Literal["pending", "active", "checked_out", "cancelled"]

class ReservationBase(BaseModel):
    guest_id: int
    room_id: int
    start_date: date
    period: Period
    periods_count: conint(ge=1) = 1
    price_bs: condecimal(max_digits=12, decimal_places=2)
    rate_usd: Optional[condecimal(max_digits=12, decimal_places=6)] = None
    rate_eur: Optional[condecimal(max_digits=12, decimal_places=6)] = None
    notes: Optional[str] = Field(None, max_length=500)

class ReservationCreate(ReservationBase):
    pass

class ReservationUpdate(BaseModel):
    start_date: Optional[date] = None
    period: Optional[Period] = None
    periods_count: Optional[conint(ge=1)] = None
    price_bs: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    rate_usd: Optional[condecimal(max_digits=12, decimal_places=6)] = None
    rate_eur: Optional[condecimal(max_digits=12, decimal_places=6)] = None
    notes: Optional[str] = Field(None, max_length=500)
    status: Optional[Status] = None

class ReservationOut(BaseModel):
    id: int
    guest_id: int
    room_id: int
    start_date: date
    end_date: date
    period: Period
    periods_count: int
    price_bs: condecimal(max_digits=12, decimal_places=2)
    rate_usd: Optional[condecimal(max_digits=12, decimal_places=6)] = None
    rate_eur: Optional[condecimal(max_digits=12, decimal_places=6)] = None
    status: Status
    notes: Optional[str] = None

    class Config:
        from_attributes = True
